import { database } from "../../config/firebase/firebase_config";
// Hàm để lưu session token
export const saveSessionTokenToDatabase = async (userId: string, sessionToken: string) => {
    try {
        // Tạo đường dẫn đến user cụ thể trong database
        const userRef = database.ref(`users/${userId}`);

        // Cập nhật session token
        await userRef.update({
            "sessionToken": sessionToken,
        });

        console.log("Session token saved successfully!");
    } catch (error: unknown) {
        if (error instanceof Error) {
            console.error("Error saving session token:", error.message);
        } else {
            console.error("Error saving session token: Unknown error");
        }
    }
};

